/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: dofrobot_types.h
 *
 * Code generated for Simulink model 'dofrobot'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Sat Mar 22 13:09:28 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Custom Processor->Custom
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef dofrobot_types_h_
#define dofrobot_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_dofrobot_T RT_MODEL_dofrobot_T;

#endif                                 /* dofrobot_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
