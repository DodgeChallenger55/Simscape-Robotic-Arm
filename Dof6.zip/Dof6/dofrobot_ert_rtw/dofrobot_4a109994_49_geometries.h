/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'dofrobot/Solver Configuration'.
 */

struct RuntimeDerivedValuesBundleTag;
void dofrobot_4a109994_49_initializeGeometries(const struct
  RuntimeDerivedValuesBundleTag *rtdv);
