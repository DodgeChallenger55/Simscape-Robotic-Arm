/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'dofrobot/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "pm_default_allocator.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ssc_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"
#include "sm_CTarget.h"

void dofrobot_4a109994_49_setTargets(const RuntimeDerivedValuesBundle *rtdv,
  CTarget *targets)
{
  (void) rtdv;
  (void) targets;
}

void dofrobot_4a109994_49_resetAsmStateVector(const void *mech, double *state)
{
  double xx[1];
  (void) mech;
  xx[0] = 0.0;
  state[0] = xx[0];
  state[1] = xx[0];
  state[2] = xx[0];
  state[3] = xx[0];
  state[4] = xx[0];
  state[5] = xx[0];
  state[6] = xx[0];
  state[7] = xx[0];
  state[8] = xx[0];
  state[9] = xx[0];
  state[10] = xx[0];
  state[11] = xx[0];
}

void dofrobot_4a109994_49_initializeTrackedAngleState(const void *mech, const
  RuntimeDerivedValuesBundle *rtdv, const int *modeVector, const double
  *motionData, double *state)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  (void) mech;
  (void) rtdvd;
  (void) rtdvi;
  (void) state;
  (void) modeVector;
  (void) motionData;
}

void dofrobot_4a109994_49_computeDiscreteState(const void *mech, const
  RuntimeDerivedValuesBundle *rtdv, const int *modeVector, double *state)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  (void) mech;
  (void) rtdvd;
  (void) rtdvi;
  (void) state;
  (void) modeVector;
}

void dofrobot_4a109994_49_adjustPosition(const void *mech, const double
  *dofDeltas, double *state)
{
  (void) mech;
  state[0] = state[0] + dofDeltas[0];
  state[2] = state[2] + dofDeltas[1];
  state[4] = state[4] + dofDeltas[2];
  state[6] = state[6] + dofDeltas[3];
  state[8] = state[8] + dofDeltas[4];
  state[10] = state[10] + dofDeltas[5];
}

static void perturbAsmJointPrimitiveState_0_0(double mag, double *state)
{
  state[0] = state[0] + mag;
}

static void perturbAsmJointPrimitiveState_0_0v(double mag, double *state)
{
  state[0] = state[0] + mag;
  state[1] = state[1] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_1_0(double mag, double *state)
{
  state[2] = state[2] + mag;
}

static void perturbAsmJointPrimitiveState_1_0v(double mag, double *state)
{
  state[2] = state[2] + mag;
  state[3] = state[3] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_2_0(double mag, double *state)
{
  state[4] = state[4] + mag;
}

static void perturbAsmJointPrimitiveState_2_0v(double mag, double *state)
{
  state[4] = state[4] + mag;
  state[5] = state[5] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_3_0(double mag, double *state)
{
  state[6] = state[6] + mag;
}

static void perturbAsmJointPrimitiveState_3_0v(double mag, double *state)
{
  state[6] = state[6] + mag;
  state[7] = state[7] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_4_0(double mag, double *state)
{
  state[8] = state[8] + mag;
}

static void perturbAsmJointPrimitiveState_4_0v(double mag, double *state)
{
  state[8] = state[8] + mag;
  state[9] = state[9] - 0.875 * mag;
}

static void perturbAsmJointPrimitiveState_5_0(double mag, double *state)
{
  state[10] = state[10] + mag;
}

static void perturbAsmJointPrimitiveState_5_0v(double mag, double *state)
{
  state[10] = state[10] + mag;
  state[11] = state[11] - 0.875 * mag;
}

void dofrobot_4a109994_49_perturbAsmJointPrimitiveState(const void *mech, size_t
  stageIdx, size_t primIdx, double mag, boolean_T doPerturbVelocity, double
  *state)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) mag;
  (void) doPerturbVelocity;
  (void) state;
  switch ((stageIdx * 6 + primIdx) * 2 + (doPerturbVelocity ? 1 : 0))
  {
   case 0:
    perturbAsmJointPrimitiveState_0_0(mag, state);
    break;

   case 1:
    perturbAsmJointPrimitiveState_0_0v(mag, state);
    break;

   case 12:
    perturbAsmJointPrimitiveState_1_0(mag, state);
    break;

   case 13:
    perturbAsmJointPrimitiveState_1_0v(mag, state);
    break;

   case 24:
    perturbAsmJointPrimitiveState_2_0(mag, state);
    break;

   case 25:
    perturbAsmJointPrimitiveState_2_0v(mag, state);
    break;

   case 36:
    perturbAsmJointPrimitiveState_3_0(mag, state);
    break;

   case 37:
    perturbAsmJointPrimitiveState_3_0v(mag, state);
    break;

   case 48:
    perturbAsmJointPrimitiveState_4_0(mag, state);
    break;

   case 49:
    perturbAsmJointPrimitiveState_4_0v(mag, state);
    break;

   case 60:
    perturbAsmJointPrimitiveState_5_0(mag, state);
    break;

   case 61:
    perturbAsmJointPrimitiveState_5_0v(mag, state);
    break;
  }
}

void dofrobot_4a109994_49_computePosDofBlendMatrix(const void *mech, size_t
  stageIdx, size_t primIdx, const double *state, int partialType, double *matrix)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) state;
  (void) partialType;
  (void) matrix;
  switch ((stageIdx * 6 + primIdx))
  {
  }
}

void dofrobot_4a109994_49_computeVelDofBlendMatrix(const void *mech, size_t
  stageIdx, size_t primIdx, const double *state, int partialType, double *matrix)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) state;
  (void) partialType;
  (void) matrix;
  switch ((stageIdx * 6 + primIdx))
  {
  }
}

void dofrobot_4a109994_49_projectPartiallyTargetedPos(const void *mech, size_t
  stageIdx, size_t primIdx, const double *origState, int partialType, double
  *state)
{
  (void) mech;
  (void) stageIdx;
  (void) primIdx;
  (void) origState;
  (void) partialType;
  (void) state;
  switch ((stageIdx * 6 + primIdx))
  {
  }
}

void dofrobot_4a109994_49_propagateMotion(const void *mech, const
  RuntimeDerivedValuesBundle *rtdv, const double *state, double *motionData)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  double xx[90];
  (void) mech;
  (void) rtdvd;
  (void) rtdvi;
  xx[0] = - 0.9999999642396405;
  xx[1] = - 6.77309530153769e-5;
  xx[2] = - 3.902037658098934e-6;
  xx[3] = 2.586851566524773e-4;
  xx[4] = 0.5;
  xx[5] = xx[4] * state[0];
  xx[6] = 5.173697662260723e-4;
  xx[7] = sin(xx[5]);
  xx[8] = 0.9999998569890159;
  xx[9] = 1.354639199855345e-4;
  xx[10] = cos(xx[5]);
  xx[11] = - (xx[6] * xx[7]);
  xx[12] = xx[8] * xx[7];
  xx[13] = - (xx[9] * xx[7]);
  pm_math_Quaternion_compose_ra(xx + 0, xx + 10, xx + 14);
  xx[0] = 5.038683304353288e-5;
  xx[1] = - 0.09753991213032277;
  xx[2] = 1.081348051659294e-3;
  pm_math_Quaternion_xform_ra(xx + 14, xx + 0, xx + 10);
  xx[0] = - 0.4953619905545896;
  xx[1] = 0.5043382683880024;
  xx[2] = 0.4956278427236681;
  xx[3] = - 0.5045913701900471;
  xx[5] = xx[4] * state[2];
  xx[7] = 1.670506997464136e-6;
  xx[13] = sin(xx[5]);
  xx[18] = 3.558786352277872e-7;
  xx[19] = 0.9999999999985414;
  xx[20] = cos(xx[5]);
  xx[21] = xx[7] * xx[13];
  xx[22] = - (xx[18] * xx[13]);
  xx[23] = xx[19] * xx[13];
  pm_math_Quaternion_compose_ra(xx + 0, xx + 20, xx + 24);
  xx[0] = 0.01287257786788114;
  xx[1] = - 0.2034011245097346;
  xx[2] = - 0.1220009378214448;
  pm_math_Quaternion_xform_ra(xx + 24, xx + 0, xx + 20);
  xx[0] = 0.1189592790844112 - xx[20];
  xx[1] = 0.08052163005907517 - xx[21];
  xx[2] = 1.058159996604281e-3 - xx[22];
  xx[20] = 9.480426585502591e-9;
  xx[21] = - 0.9975807686623547;
  xx[22] = - 0.0695169763035848;
  xx[23] = 7.952980839545705e-7;
  xx[3] = xx[4] * state[4];
  xx[5] = 1.957162315325112e-8;
  xx[13] = sin(xx[3]);
  xx[28] = 4.546458783983475e-7;
  xx[29] = cos(xx[3]);
  xx[30] = - (xx[5] * xx[13]);
  xx[31] = - (xx[28] * xx[13]);
  xx[32] = xx[13];
  pm_math_Quaternion_compose_ra(xx + 20, xx + 29, xx + 33);
  xx[20] = - 0.110894494200688;
  xx[21] = 0.0154867249358695;
  xx[22] = - 0.1059999900921876;
  pm_math_Quaternion_xform_ra(xx + 33, xx + 20, xx + 29);
  xx[3] = 0.01288586484519144 - xx[29];
  xx[13] = 0.2466699000136801 - xx[30];
  xx[20] = 0.105000222327352 - xx[31];
  xx[29] = - 0.9969223933167708;
  xx[30] = - 1.251550649661315e-5;
  xx[31] = - 1.605640023827348e-6;
  xx[32] = - 0.07839478008353806;
  xx[21] = xx[4] * state[6];
  xx[22] = sin(xx[21]);
  xx[23] = 1.603380046510949e-7;
  xx[37] = 1.32948766407015e-6;
  xx[38] = cos(xx[21]);
  xx[39] = xx[22];
  xx[40] = xx[23] * xx[22];
  xx[41] = xx[37] * xx[22];
  pm_math_Quaternion_compose_ra(xx + 29, xx + 38, xx + 42);
  xx[29] = - 0.08431088394536904;
  xx[30] = - 4.182923273576212e-9;
  xx[31] = - 1.124233103218932e-7;
  pm_math_Quaternion_xform_ra(xx + 42, xx + 29, xx + 38);
  xx[21] = 0.1850689934784395 - xx[38];
  xx[22] = 0.01980092439507778 - xx[39];
  xx[29] = 1.766174209076842e-8 - xx[40];
  xx[38] = 0.9999999999265812;
  xx[39] = - 1.204409374205106e-5;
  xx[40] = - 1.327125567115377e-6;
  xx[41] = 1.267821922927163e-7;
  xx[30] = xx[4] * state[8];
  xx[31] = 1.324762725505895e-6;
  xx[32] = sin(xx[30]);
  xx[46] = 6.715390676029173e-7;
  xx[47] = 0.9999999999988969;
  xx[48] = cos(xx[30]);
  xx[49] = xx[31] * xx[32];
  xx[50] = xx[46] * xx[32];
  xx[51] = xx[47] * xx[32];
  pm_math_Quaternion_compose_ra(xx + 38, xx + 48, xx + 52);
  xx[38] = - 0.01425643892542409;
  xx[39] = 1.739047248594257e-8;
  xx[40] = 0.02699996676987726;
  pm_math_Quaternion_xform_ra(xx + 52, xx + 38, xx + 48);
  xx[30] = 0.0826890801582081 - xx[48];
  xx[32] = 6.911061428892078e-7 - xx[49];
  xx[38] = 0.02700010959282867 - xx[50];
  xx[39] = 3.357695645410844e-7;
  xx[40] = xx[4] * state[10];
  xx[4] = sin(xx[40]);
  xx[41] = 0.9999999999997231;
  xx[48] = cos(xx[40]);
  xx[40] = xx[39] * xx[4] - xx[41] * xx[48];
  xx[49] = xx[39] * xx[48] + xx[41] * xx[4];
  xx[39] = 6.623813471604954e-7;
  xx[41] = 4.661299618512291e-8;
  xx[50] = xx[39] * xx[48] + xx[41] * xx[4];
  xx[51] = - xx[50];
  xx[56] = xx[41] * xx[48] - xx[39] * xx[4];
  xx[57] = xx[49];
  xx[58] = xx[51];
  xx[59] = xx[56];
  xx[4] = 3.375337533753464e-4;
  xx[39] = xx[4] * xx[50];
  xx[41] = 2.5e-3;
  xx[48] = xx[56] * xx[41] + xx[4] * xx[49];
  xx[60] = xx[41] * xx[50];
  xx[61] = - xx[39];
  xx[62] = - xx[48];
  xx[63] = - xx[60];
  pm_math_Vector3_cross_ra(xx + 57, xx + 61, xx + 64);
  xx[50] = 2.0;
  xx[57] = 0.06774352530590996 - ((xx[64] - xx[40] * xx[39]) * xx[50] - xx[41]);
  xx[39] = - (8.385650171711512e-9 + (xx[65] - xx[40] * xx[48]) * xx[50]);
  xx[41] = - (1.418606313216347e-7 + xx[4] + xx[50] * (xx[66] - xx[40] * xx[60]));
  xx[48] = - (xx[6] * state[1]);
  xx[6] = xx[8] * state[1];
  xx[8] = - (xx[9] * state[1]);
  xx[9] = 1.068134758162427e-3 * state[1];
  xx[50] = 5.526311907762543e-7 * state[1];
  xx[58] = 7.737569891442885e-8 * state[1];
  xx[59] = xx[48];
  xx[60] = xx[6];
  xx[61] = xx[8];
  pm_math_Quaternion_inverseXform_ra(xx + 24, xx + 59, xx + 62);
  xx[65] = xx[62] + xx[7] * state[3];
  xx[7] = xx[63] - xx[18] * state[3];
  xx[18] = xx[64] + xx[19] * state[3];
  pm_math_Vector3_cross_ra(xx + 59, xx + 0, xx + 62);
  xx[59] = xx[62] - xx[9];
  xx[60] = xx[63] - xx[50];
  xx[61] = xx[64] - xx[58];
  pm_math_Quaternion_inverseXform_ra(xx + 24, xx + 59, xx + 62);
  xx[19] = xx[62] - 0.2034011679269651 * state[3];
  xx[59] = xx[63] - 0.01287278167128269 * state[3];
  xx[60] = xx[64] + 3.352019263421006e-7 * state[3];
  xx[61] = xx[65];
  xx[62] = xx[7];
  xx[63] = xx[18];
  pm_math_Quaternion_inverseXform_ra(xx + 33, xx + 61, xx + 66);
  xx[64] = xx[66] - xx[5] * state[5];
  xx[5] = xx[67] - xx[28] * state[5];
  xx[28] = xx[68] + state[5];
  xx[66] = xx[3];
  xx[67] = xx[13];
  xx[68] = xx[20];
  pm_math_Vector3_cross_ra(xx + 61, xx + 66, xx + 69);
  xx[61] = xx[69] + xx[19];
  xx[62] = xx[70] + xx[59];
  xx[63] = xx[71] + xx[60];
  pm_math_Quaternion_inverseXform_ra(xx + 33, xx + 61, xx + 66);
  xx[61] = xx[66] + 0.01548667674340929 * state[5];
  xx[62] = xx[67] + 0.1108944962752683 * state[5];
  xx[63] = xx[68] + 5.072082506973512e-8 * state[5];
  xx[66] = xx[64];
  xx[67] = xx[5];
  xx[68] = xx[28];
  pm_math_Quaternion_inverseXform_ra(xx + 42, xx + 66, xx + 69);
  xx[72] = xx[69] + state[7];
  xx[73] = xx[70] + xx[23] * state[7];
  xx[23] = xx[71] + xx[37] * state[7];
  xx[69] = xx[21];
  xx[70] = xx[22];
  xx[71] = xx[29];
  pm_math_Vector3_cross_ra(xx + 66, xx + 69, xx + 74);
  xx[66] = xx[74] + xx[61];
  xx[67] = xx[75] + xx[62];
  xx[68] = xx[76] + xx[63];
  pm_math_Quaternion_inverseXform_ra(xx + 42, xx + 66, xx + 69);
  xx[37] = xx[69] + 1.24645843613117e-14 * state[7];
  xx[66] = xx[70] - 3.33030169574259e-10 * state[7];
  xx[67] = xx[71] - 9.335315628598044e-9 * state[7];
  xx[68] = xx[72];
  xx[69] = xx[73];
  xx[70] = xx[23];
  pm_math_Quaternion_inverseXform_ra(xx + 52, xx + 68, xx + 74);
  xx[71] = xx[74] + xx[31] * state[9];
  xx[31] = xx[75] + xx[46] * state[9];
  xx[46] = xx[76] + xx[47] * state[9];
  xx[74] = xx[30];
  xx[75] = xx[32];
  xx[76] = xx[38];
  pm_math_Vector3_cross_ra(xx + 68, xx + 74, xx + 77);
  xx[68] = xx[77] + xx[37];
  xx[69] = xx[78] + xx[66];
  xx[70] = xx[79] + xx[67];
  pm_math_Quaternion_inverseXform_ra(xx + 52, xx + 68, xx + 74);
  xx[47] = xx[74] - 7.410600240297415e-10 * state[9];
  xx[68] = xx[75] + 0.01425647469395793 * state[9];
  xx[69] = xx[76] - 9.573778741566957e-9 * state[9];
  xx[74] = xx[40];
  xx[75] = xx[49];
  xx[76] = xx[51];
  xx[77] = xx[56];
  xx[78] = xx[71];
  xx[79] = xx[31];
  xx[80] = xx[46];
  pm_math_Quaternion_inverseXform_ra(xx + 74, xx + 78, xx + 81);
  xx[84] = xx[57];
  xx[85] = xx[39];
  xx[86] = xx[41];
  pm_math_Vector3_cross_ra(xx + 78, xx + 84, xx + 87);
  xx[78] = xx[87] + xx[47];
  xx[79] = xx[88] + xx[68];
  xx[80] = xx[89] + xx[69];
  pm_math_Quaternion_inverseXform_ra(xx + 74, xx + 78, xx + 84);
  motionData[0] = xx[14];
  motionData[1] = xx[15];
  motionData[2] = xx[16];
  motionData[3] = xx[17];
  motionData[4] = - xx[10];
  motionData[5] = 0.22 - xx[11];
  motionData[6] = - xx[12];
  motionData[7] = xx[24];
  motionData[8] = xx[25];
  motionData[9] = xx[26];
  motionData[10] = xx[27];
  motionData[11] = xx[0];
  motionData[12] = xx[1];
  motionData[13] = xx[2];
  motionData[14] = xx[33];
  motionData[15] = xx[34];
  motionData[16] = xx[35];
  motionData[17] = xx[36];
  motionData[18] = xx[3];
  motionData[19] = xx[13];
  motionData[20] = xx[20];
  motionData[21] = xx[42];
  motionData[22] = xx[43];
  motionData[23] = xx[44];
  motionData[24] = xx[45];
  motionData[25] = xx[21];
  motionData[26] = xx[22];
  motionData[27] = xx[29];
  motionData[28] = xx[52];
  motionData[29] = xx[53];
  motionData[30] = xx[54];
  motionData[31] = xx[55];
  motionData[32] = xx[30];
  motionData[33] = xx[32];
  motionData[34] = xx[38];
  motionData[35] = xx[40];
  motionData[36] = xx[49];
  motionData[37] = xx[51];
  motionData[38] = xx[56];
  motionData[39] = xx[57];
  motionData[40] = xx[39];
  motionData[41] = xx[41];
  motionData[42] = xx[48];
  motionData[43] = xx[6];
  motionData[44] = xx[8];
  motionData[45] = - xx[9];
  motionData[46] = - xx[50];
  motionData[47] = - xx[58];
  motionData[48] = xx[65];
  motionData[49] = xx[7];
  motionData[50] = xx[18];
  motionData[51] = xx[19];
  motionData[52] = xx[59];
  motionData[53] = xx[60];
  motionData[54] = xx[64];
  motionData[55] = xx[5];
  motionData[56] = xx[28];
  motionData[57] = xx[61];
  motionData[58] = xx[62];
  motionData[59] = xx[63];
  motionData[60] = xx[72];
  motionData[61] = xx[73];
  motionData[62] = xx[23];
  motionData[63] = xx[37];
  motionData[64] = xx[66];
  motionData[65] = xx[67];
  motionData[66] = xx[71];
  motionData[67] = xx[31];
  motionData[68] = xx[46];
  motionData[69] = xx[47];
  motionData[70] = xx[68];
  motionData[71] = xx[69];
  motionData[72] = xx[81] - state[11];
  motionData[73] = xx[82];
  motionData[74] = xx[83];
  motionData[75] = xx[84];
  motionData[76] = xx[85] - xx[4] * state[11];
  motionData[77] = xx[86];
}

size_t dofrobot_4a109994_49_computeAssemblyPosError(const void *mech, const
  RuntimeDerivedValuesBundle *rtdv, size_t constraintIdx, const int *modeVector,
  const double *motionData, double *error)
{
  (void) mech;
  (void)rtdv;
  (void) modeVector;
  (void) motionData;
  (void) error;
  switch (constraintIdx)
  {
  }

  return 0;
}

size_t dofrobot_4a109994_49_computeAssemblyJacobian(const void *mech, const
  RuntimeDerivedValuesBundle *rtdv, size_t constraintIdx, boolean_T
  forVelocitySatisfaction, const double *state, const int *modeVector, const
  double *motionData, double *J)
{
  (void) mech;
  (void) rtdv;
  (void) state;
  (void) modeVector;
  (void) forVelocitySatisfaction;
  (void) motionData;
  (void) J;
  switch (constraintIdx)
  {
  }

  return 0;
}

size_t dofrobot_4a109994_49_computeFullAssemblyJacobian(const void *mech, const
  RuntimeDerivedValuesBundle *rtdv, const double *state, const int *modeVector,
  const double *motionData, double *J)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  (void) mech;
  (void) rtdvd;
  (void) rtdvi;
  (void) state;
  (void) modeVector;
  (void) motionData;
  (void) J;
  return 0;
}

boolean_T dofrobot_4a109994_49_isInKinematicSingularity(const void *mech, const
  RuntimeDerivedValuesBundle *rtdv, size_t constraintIdx, const int *modeVector,
  const double *motionData)
{
  (void) mech;
  (void) rtdv;
  (void) modeVector;
  (void) motionData;
  switch (constraintIdx)
  {
  }

  return 0;
}

void dofrobot_4a109994_49_convertStateVector(const void *asmMech, const
  RuntimeDerivedValuesBundle *rtdv, const void *simMech, const double *asmState,
  const int *asmModeVector, const int *simModeVector, double *simState)
{
  const double *rtdvd = rtdv->mDoubles.mValues;
  const int *rtdvi = rtdv->mInts.mValues;
  (void) asmMech;
  (void) rtdvd;
  (void) rtdvi;
  (void) simMech;
  (void) asmModeVector;
  (void) simModeVector;
  simState[0] = asmState[0];
  simState[1] = asmState[1];
  simState[2] = asmState[2];
  simState[3] = asmState[3];
  simState[4] = asmState[4];
  simState[5] = asmState[5];
  simState[6] = asmState[6];
  simState[7] = asmState[7];
  simState[8] = asmState[8];
  simState[9] = asmState[9];
  simState[10] = asmState[10];
  simState[11] = asmState[11];
}
