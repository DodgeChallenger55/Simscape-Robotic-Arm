/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: dofrobot.h
 *
 * Code generated for Simulink model 'dofrobot'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Sat Mar 22 13:09:28 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Custom Processor->Custom
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef dofrobot_h_
#define dofrobot_h_
#ifndef dofrobot_COMMON_INCLUDES_
#define dofrobot_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "dt_info.h"
#include "ext_work.h"
#include "nesl_rtw.h"
#include "dofrobot_4a109994_1_gateway.h"
#endif                                 /* dofrobot_COMMON_INCLUDES_ */

#include "dofrobot_types.h"
#include <float.h>
#include <string.h>

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
#define rtmGetRTWExtModeInfo(rtm)      ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T dv[24];
  real_T dv1[24];
  NeModelParameters modelParameters;
  real_T INPUT_1_1_1[4];               /* '<S27>/INPUT_1_1_1' */
  real_T INPUT_2_1_1[4];               /* '<S27>/INPUT_2_1_1' */
  real_T INPUT_3_1_1[4];               /* '<S27>/INPUT_3_1_1' */
  real_T INPUT_4_1_1[4];               /* '<S27>/INPUT_4_1_1' */
  real_T INPUT_5_1_1[4];               /* '<S27>/INPUT_5_1_1' */
  real_T INPUT_6_1_1[4];               /* '<S27>/INPUT_6_1_1' */
  int_T iv[7];
  int_T iv1[7];
} B_dofrobot_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T INPUT_1_1_1_Discrete[2];      /* '<S27>/INPUT_1_1_1' */
  real_T INPUT_2_1_1_Discrete[2];      /* '<S27>/INPUT_2_1_1' */
  real_T INPUT_3_1_1_Discrete[2];      /* '<S27>/INPUT_3_1_1' */
  real_T INPUT_4_1_1_Discrete[2];      /* '<S27>/INPUT_4_1_1' */
  real_T INPUT_5_1_1_Discrete[2];      /* '<S27>/INPUT_5_1_1' */
  real_T INPUT_6_1_1_Discrete[2];      /* '<S27>/INPUT_6_1_1' */
  real_T STATE_1_Discrete;             /* '<S27>/STATE_1' */
  real_T STATE_1_ZcValueStore;         /* '<S27>/STATE_1' */
  void* SINK_1_RtwLogger;              /* '<S27>/SINK_1' */
  void* SINK_1_RtwLogBuffer;           /* '<S27>/SINK_1' */
  void* SINK_1_RtwLogFcnManager;       /* '<S27>/SINK_1' */
  void* SINK_1_InstRtwLogger;          /* '<S27>/SINK_1' */
  void* SINK_1_InstRtwLogBuffer;       /* '<S27>/SINK_1' */
  void* STATE_1_Simulator;             /* '<S27>/STATE_1' */
  void* STATE_1_SimData;               /* '<S27>/STATE_1' */
  void* STATE_1_DiagMgr;               /* '<S27>/STATE_1' */
  void* STATE_1_ZcLogger;              /* '<S27>/STATE_1' */
  void* STATE_1_TsInfo;                /* '<S27>/STATE_1' */
  int_T STATE_1_Modes;                 /* '<S27>/STATE_1' */
  uint8_T STATE_1_ZcSignalDir;         /* '<S27>/STATE_1' */
  uint8_T STATE_1_ZcStateStore;        /* '<S27>/STATE_1' */
  boolean_T STATE_1_FirstOutput;       /* '<S27>/STATE_1' */
} DW_dofrobot_T;

/* Invariant block signals (default storage) */
typedef struct {
  const real_T SliderGain;             /* '<S14>/Slider Gain' */
  const real_T Gain1;                  /* '<Root>/Gain1' */
  const real_T SliderGain_k;           /* '<S15>/Slider Gain' */
  const real_T Gain2;                  /* '<Root>/Gain2' */
  const real_T SliderGain_h;           /* '<S16>/Slider Gain' */
  const real_T Gain3;                  /* '<Root>/Gain3' */
  const real_T SliderGain_k0;          /* '<S17>/Slider Gain' */
  const real_T Gain4;                  /* '<Root>/Gain4' */
  const real_T SliderGain_d;           /* '<S18>/Slider Gain' */
  const real_T Gain5;                  /* '<Root>/Gain5' */
  const real_T SliderGain_c;           /* '<S19>/Slider Gain' */
  const real_T Gain6;                  /* '<Root>/Gain6' */
} ConstB_dofrobot_T;

/* Real-time Model Data Structure */
struct tag_RTM_dofrobot_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block signals (default storage) */
extern B_dofrobot_T dofrobot_B;

/* Block states (default storage) */
extern DW_dofrobot_T dofrobot_DW;
extern const ConstB_dofrobot_T dofrobot_ConstB;/* constant block i/o */

/* Model entry point functions */
extern void dofrobot_initialize(void);
extern void dofrobot_step(void);
extern void dofrobot_terminate(void);

/* Real-time Model object */
extern RT_MODEL_dofrobot_T *const dofrobot_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'dofrobot'
 * '<S1>'   : 'dofrobot/Base1_1_RIGID'
 * '<S2>'   : 'dofrobot/Part2_1_RIGID'
 * '<S3>'   : 'dofrobot/Part3_1_RIGID'
 * '<S4>'   : 'dofrobot/Part4_1_RIGID'
 * '<S5>'   : 'dofrobot/Part5_1_RIGID'
 * '<S6>'   : 'dofrobot/Part6_1_RIGID'
 * '<S7>'   : 'dofrobot/Part7_1_RIGID'
 * '<S8>'   : 'dofrobot/Simulink-PS Converter'
 * '<S9>'   : 'dofrobot/Simulink-PS Converter1'
 * '<S10>'  : 'dofrobot/Simulink-PS Converter2'
 * '<S11>'  : 'dofrobot/Simulink-PS Converter3'
 * '<S12>'  : 'dofrobot/Simulink-PS Converter4'
 * '<S13>'  : 'dofrobot/Simulink-PS Converter5'
 * '<S14>'  : 'dofrobot/Slider Gain'
 * '<S15>'  : 'dofrobot/Slider Gain1'
 * '<S16>'  : 'dofrobot/Slider Gain2'
 * '<S17>'  : 'dofrobot/Slider Gain3'
 * '<S18>'  : 'dofrobot/Slider Gain4'
 * '<S19>'  : 'dofrobot/Slider Gain5'
 * '<S20>'  : 'dofrobot/Solver Configuration'
 * '<S21>'  : 'dofrobot/Simulink-PS Converter/EVAL_KEY'
 * '<S22>'  : 'dofrobot/Simulink-PS Converter1/EVAL_KEY'
 * '<S23>'  : 'dofrobot/Simulink-PS Converter2/EVAL_KEY'
 * '<S24>'  : 'dofrobot/Simulink-PS Converter3/EVAL_KEY'
 * '<S25>'  : 'dofrobot/Simulink-PS Converter4/EVAL_KEY'
 * '<S26>'  : 'dofrobot/Simulink-PS Converter5/EVAL_KEY'
 * '<S27>'  : 'dofrobot/Solver Configuration/EVAL_KEY'
 */
#endif                                 /* dofrobot_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
