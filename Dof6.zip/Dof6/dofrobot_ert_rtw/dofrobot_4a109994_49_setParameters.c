/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'dofrobot/Solver Configuration'.
 */

#include <math.h>
#include <string.h>
#include "pm_std.h"
#include "pm_default_allocator.h"
#include "sm_std.h"
#include "ne_std.h"
#include "ssc_dae.h"
#include "sm_ssci_run_time_errors.h"
#include "sm_RuntimeDerivedValuesBundle.h"

void dofrobot_4a109994_49_computeRuntimeParameters(real_T *in, real_T *out)
{
  (void) in;
  (void) out;
}

void dofrobot_4a109994_49_computeAsmRuntimeDerivedValuesDoubles(const double
  *rtp, double *rtdvd)
{
  (void) rtp;
  (void) rtdvd;
}

void dofrobot_4a109994_49_computeAsmRuntimeDerivedValuesInts(const double *rtp,
  int *rtdvi)
{
  (void) rtp;
  (void) rtdvi;
}

void dofrobot_4a109994_49_computeAsmRuntimeDerivedValues(const double *rtp,
  RuntimeDerivedValuesBundle *rtdv)
{
  dofrobot_4a109994_49_computeAsmRuntimeDerivedValuesDoubles(rtp,
    rtdv->mDoubles.mValues);
  dofrobot_4a109994_49_computeAsmRuntimeDerivedValuesInts(rtp,
    rtdv->mInts.mValues);
}

void dofrobot_4a109994_49_computeSimRuntimeDerivedValuesDoubles(const double
  *rtp, double *rtdvd)
{
  (void) rtp;
  (void) rtdvd;
}

void dofrobot_4a109994_49_computeSimRuntimeDerivedValuesInts(const double *rtp,
  int *rtdvi)
{
  (void) rtp;
  (void) rtdvi;
}

void dofrobot_4a109994_49_computeSimRuntimeDerivedValues(const double *rtp,
  RuntimeDerivedValuesBundle *rtdv)
{
  dofrobot_4a109994_49_computeSimRuntimeDerivedValuesDoubles(rtp,
    rtdv->mDoubles.mValues);
  dofrobot_4a109994_49_computeSimRuntimeDerivedValuesInts(rtp,
    rtdv->mInts.mValues);
}
