/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: dofrobot_data.c
 *
 * Code generated for Simulink model 'dofrobot'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Sat Mar 22 13:09:28 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Custom Processor->Custom
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "dofrobot.h"

/* Invariant block signals (default storage) */
const ConstB_dofrobot_T dofrobot_ConstB = {
  1.0,                                 /* '<S14>/Slider Gain' */
  0.017453292519943295,                /* '<Root>/Gain1' */
  1.0,                                 /* '<S15>/Slider Gain' */
  0.017453292519943295,                /* '<Root>/Gain2' */
  1.0,                                 /* '<S16>/Slider Gain' */
  0.017453292519943295,                /* '<Root>/Gain3' */
  1.0,                                 /* '<S17>/Slider Gain' */
  0.017453292519943295,                /* '<Root>/Gain4' */
  1.0,                                 /* '<S18>/Slider Gain' */
  0.017453292519943295,                /* '<Root>/Gain5' */
  1.0,                                 /* '<S19>/Slider Gain' */
  0.017453292519943295                 /* '<Root>/Gain6' */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
