/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'dofrobot/Solver Configuration'.
 */

#ifndef __dofrobot_4a109994_1_gateway_h__
#define __dofrobot_4a109994_1_gateway_h__
#ifdef __cplusplus

extern "C"
{

#endif

  extern void dofrobot_4a109994_1_gateway(void);

#ifdef __cplusplus

}

#endif
#endif                           /* #ifndef __dofrobot_4a109994_1_gateway_h__ */
