/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: dofrobot.c
 *
 * Code generated for Simulink model 'dofrobot'.
 *
 * Model version                  : 1.3
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Sat Mar 22 13:09:28 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Custom Processor->Custom
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "dofrobot.h"
#include "rtwtypes.h"
#include <stddef.h>
#include "dofrobot_private.h"
#include "dofrobot_dt.h"

/* Block signals (default storage) */
B_dofrobot_T dofrobot_B;

/* Block states (default storage) */
DW_dofrobot_T dofrobot_DW;

/* Real-time model */
static RT_MODEL_dofrobot_T dofrobot_M_;
RT_MODEL_dofrobot_T *const dofrobot_M = &dofrobot_M_;

/* Model step function */
void dofrobot_step(void)
{
  {
    NeslSimulationData *simulationData;
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    char *msg;
    real_T time;
    real_T time_0;
    int32_T tmp_0;
    boolean_T tmp;
    boolean_T tmp_1;

    /* SimscapeInputBlock: '<S27>/INPUT_1_1_1' incorporates:
     *  SimscapeExecutionBlock: '<S27>/STATE_1'
     *  SimscapeInputBlock: '<S27>/INPUT_2_1_1'
     *  SimscapeInputBlock: '<S27>/INPUT_3_1_1'
     *  SimscapeInputBlock: '<S27>/INPUT_4_1_1'
     *  SimscapeInputBlock: '<S27>/INPUT_5_1_1'
     *  SimscapeInputBlock: '<S27>/INPUT_6_1_1'
     */
    dofrobot_B.INPUT_1_1_1[0] = dofrobot_ConstB.Gain1;
    dofrobot_B.INPUT_1_1_1[1] = 0.0;
    dofrobot_B.INPUT_1_1_1[2] = 0.0;
    tmp_1 = rtmIsMajorTimeStep(dofrobot_M);
    if (tmp_1) {
      dofrobot_DW.INPUT_1_1_1_Discrete[0] = !(dofrobot_B.INPUT_1_1_1[0] ==
        dofrobot_DW.INPUT_1_1_1_Discrete[1]);
      dofrobot_DW.INPUT_1_1_1_Discrete[1] = dofrobot_B.INPUT_1_1_1[0];
    }

    dofrobot_B.INPUT_1_1_1[0] = dofrobot_DW.INPUT_1_1_1_Discrete[1];
    dofrobot_B.INPUT_1_1_1[3] = dofrobot_DW.INPUT_1_1_1_Discrete[0];

    /* End of SimscapeInputBlock: '<S27>/INPUT_1_1_1' */

    /* SimscapeInputBlock: '<S27>/INPUT_2_1_1' */
    dofrobot_B.INPUT_2_1_1[0] = dofrobot_ConstB.Gain2;
    dofrobot_B.INPUT_2_1_1[1] = 0.0;
    dofrobot_B.INPUT_2_1_1[2] = 0.0;
    if (tmp_1) {
      dofrobot_DW.INPUT_2_1_1_Discrete[0] = !(dofrobot_B.INPUT_2_1_1[0] ==
        dofrobot_DW.INPUT_2_1_1_Discrete[1]);
      dofrobot_DW.INPUT_2_1_1_Discrete[1] = dofrobot_B.INPUT_2_1_1[0];
    }

    dofrobot_B.INPUT_2_1_1[0] = dofrobot_DW.INPUT_2_1_1_Discrete[1];
    dofrobot_B.INPUT_2_1_1[3] = dofrobot_DW.INPUT_2_1_1_Discrete[0];

    /* SimscapeInputBlock: '<S27>/INPUT_3_1_1' */
    dofrobot_B.INPUT_3_1_1[0] = dofrobot_ConstB.Gain3;
    dofrobot_B.INPUT_3_1_1[1] = 0.0;
    dofrobot_B.INPUT_3_1_1[2] = 0.0;
    if (tmp_1) {
      dofrobot_DW.INPUT_3_1_1_Discrete[0] = !(dofrobot_B.INPUT_3_1_1[0] ==
        dofrobot_DW.INPUT_3_1_1_Discrete[1]);
      dofrobot_DW.INPUT_3_1_1_Discrete[1] = dofrobot_B.INPUT_3_1_1[0];
    }

    dofrobot_B.INPUT_3_1_1[0] = dofrobot_DW.INPUT_3_1_1_Discrete[1];
    dofrobot_B.INPUT_3_1_1[3] = dofrobot_DW.INPUT_3_1_1_Discrete[0];

    /* SimscapeInputBlock: '<S27>/INPUT_4_1_1' */
    dofrobot_B.INPUT_4_1_1[0] = dofrobot_ConstB.Gain4;
    dofrobot_B.INPUT_4_1_1[1] = 0.0;
    dofrobot_B.INPUT_4_1_1[2] = 0.0;
    if (tmp_1) {
      dofrobot_DW.INPUT_4_1_1_Discrete[0] = !(dofrobot_B.INPUT_4_1_1[0] ==
        dofrobot_DW.INPUT_4_1_1_Discrete[1]);
      dofrobot_DW.INPUT_4_1_1_Discrete[1] = dofrobot_B.INPUT_4_1_1[0];
    }

    dofrobot_B.INPUT_4_1_1[0] = dofrobot_DW.INPUT_4_1_1_Discrete[1];
    dofrobot_B.INPUT_4_1_1[3] = dofrobot_DW.INPUT_4_1_1_Discrete[0];

    /* SimscapeInputBlock: '<S27>/INPUT_5_1_1' */
    dofrobot_B.INPUT_5_1_1[0] = dofrobot_ConstB.Gain5;
    dofrobot_B.INPUT_5_1_1[1] = 0.0;
    dofrobot_B.INPUT_5_1_1[2] = 0.0;
    if (tmp_1) {
      dofrobot_DW.INPUT_5_1_1_Discrete[0] = !(dofrobot_B.INPUT_5_1_1[0] ==
        dofrobot_DW.INPUT_5_1_1_Discrete[1]);
      dofrobot_DW.INPUT_5_1_1_Discrete[1] = dofrobot_B.INPUT_5_1_1[0];
    }

    dofrobot_B.INPUT_5_1_1[0] = dofrobot_DW.INPUT_5_1_1_Discrete[1];
    dofrobot_B.INPUT_5_1_1[3] = dofrobot_DW.INPUT_5_1_1_Discrete[0];

    /* SimscapeInputBlock: '<S27>/INPUT_6_1_1' */
    dofrobot_B.INPUT_6_1_1[0] = dofrobot_ConstB.Gain6;
    dofrobot_B.INPUT_6_1_1[1] = 0.0;
    dofrobot_B.INPUT_6_1_1[2] = 0.0;
    if (tmp_1) {
      dofrobot_DW.INPUT_6_1_1_Discrete[0] = !(dofrobot_B.INPUT_6_1_1[0] ==
        dofrobot_DW.INPUT_6_1_1_Discrete[1]);
      dofrobot_DW.INPUT_6_1_1_Discrete[1] = dofrobot_B.INPUT_6_1_1[0];
    }

    dofrobot_B.INPUT_6_1_1[0] = dofrobot_DW.INPUT_6_1_1_Discrete[1];
    dofrobot_B.INPUT_6_1_1[3] = dofrobot_DW.INPUT_6_1_1_Discrete[0];

    /* SimscapeExecutionBlock: '<S27>/STATE_1' */
    simulationData = (NeslSimulationData *)dofrobot_DW.STATE_1_SimData;
    time = dofrobot_M->Timing.t[0];
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = NULL;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX = &dofrobot_DW.STATE_1_Discrete;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX = &dofrobot_DW.STATE_1_Modes;
    tmp = false;
    simulationData->mData->mFoundZcEvents = tmp;
    simulationData->mData->mHadEvents = false;
    simulationData->mData->mIsMajorTimeStep = tmp_1;
    tmp_1 = false;
    simulationData->mData->mIsSolverAssertCheck = tmp_1;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = rtsiIsModeUpdateTimeStep
      (&dofrobot_M->solverInfo);
    dofrobot_B.iv[0] = 0;
    dofrobot_B.dv[0] = dofrobot_B.INPUT_1_1_1[0];
    dofrobot_B.dv[1] = dofrobot_B.INPUT_1_1_1[1];
    dofrobot_B.dv[2] = dofrobot_B.INPUT_1_1_1[2];
    dofrobot_B.dv[3] = dofrobot_B.INPUT_1_1_1[3];
    dofrobot_B.iv[1] = 4;
    dofrobot_B.dv[4] = dofrobot_B.INPUT_2_1_1[0];
    dofrobot_B.dv[5] = dofrobot_B.INPUT_2_1_1[1];
    dofrobot_B.dv[6] = dofrobot_B.INPUT_2_1_1[2];
    dofrobot_B.dv[7] = dofrobot_B.INPUT_2_1_1[3];
    dofrobot_B.iv[2] = 8;
    dofrobot_B.dv[8] = dofrobot_B.INPUT_3_1_1[0];
    dofrobot_B.dv[9] = dofrobot_B.INPUT_3_1_1[1];
    dofrobot_B.dv[10] = dofrobot_B.INPUT_3_1_1[2];
    dofrobot_B.dv[11] = dofrobot_B.INPUT_3_1_1[3];
    dofrobot_B.iv[3] = 12;
    dofrobot_B.dv[12] = dofrobot_B.INPUT_4_1_1[0];
    dofrobot_B.dv[13] = dofrobot_B.INPUT_4_1_1[1];
    dofrobot_B.dv[14] = dofrobot_B.INPUT_4_1_1[2];
    dofrobot_B.dv[15] = dofrobot_B.INPUT_4_1_1[3];
    dofrobot_B.iv[4] = 16;
    dofrobot_B.dv[16] = dofrobot_B.INPUT_5_1_1[0];
    dofrobot_B.dv[17] = dofrobot_B.INPUT_5_1_1[1];
    dofrobot_B.dv[18] = dofrobot_B.INPUT_5_1_1[2];
    dofrobot_B.dv[19] = dofrobot_B.INPUT_5_1_1[3];
    dofrobot_B.iv[5] = 20;
    dofrobot_B.dv[20] = dofrobot_B.INPUT_6_1_1[0];
    dofrobot_B.dv[21] = dofrobot_B.INPUT_6_1_1[1];
    dofrobot_B.dv[22] = dofrobot_B.INPUT_6_1_1[2];
    dofrobot_B.dv[23] = dofrobot_B.INPUT_6_1_1[3];
    dofrobot_B.iv[6] = 24;
    simulationData->mData->mInputValues.mN = 24;
    simulationData->mData->mInputValues.mX = &dofrobot_B.dv[0];
    simulationData->mData->mInputOffsets.mN = 7;
    simulationData->mData->mInputOffsets.mX = &dofrobot_B.iv[0];
    simulationData->mData->mOutputs.mN = 0;
    simulationData->mData->mOutputs.mX = NULL;
    simulationData->mData->mTolerances.mN = 0;
    simulationData->mData->mTolerances.mX = NULL;
    simulationData->mData->mCstateHasChanged = false;
    simulationData->mData->mDstateHasChanged = false;
    time_0 = dofrobot_M->Timing.t[0];
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time_0;
    simulationData->mData->mSampleHits.mN = 0;
    simulationData->mData->mSampleHits.mX = NULL;
    simulationData->mData->mIsFundamentalSampleHit = false;
    simulationData->mData->mHadEvents = false;
    diagnosticManager = (NeuDiagnosticManager *)dofrobot_DW.STATE_1_DiagMgr;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_0 = ne_simulator_method((NeslSimulator *)dofrobot_DW.STATE_1_Simulator,
      NESL_SIM_OUTPUTS, simulationData, diagnosticManager);
    if (tmp_0 != 0) {
      tmp_1 = error_buffer_is_empty(rtmGetErrorStatus(dofrobot_M));
      if (tmp_1) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(dofrobot_M, msg);
      }
    }
  }

  {
    NeslSimulationData *simulationData;
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    char *msg;
    real_T time;
    int32_T tmp_0;
    boolean_T tmp;

    /* Update for SimscapeExecutionBlock: '<S27>/STATE_1' */
    simulationData = (NeslSimulationData *)dofrobot_DW.STATE_1_SimData;
    time = dofrobot_M->Timing.t[0];
    simulationData->mData->mTime.mN = 1;
    simulationData->mData->mTime.mX = &time;
    simulationData->mData->mContStates.mN = 0;
    simulationData->mData->mContStates.mX = NULL;
    simulationData->mData->mDiscStates.mN = 0;
    simulationData->mData->mDiscStates.mX = &dofrobot_DW.STATE_1_Discrete;
    simulationData->mData->mModeVector.mN = 0;
    simulationData->mData->mModeVector.mX = &dofrobot_DW.STATE_1_Modes;
    tmp = false;
    simulationData->mData->mFoundZcEvents = tmp;
    simulationData->mData->mHadEvents = false;
    simulationData->mData->mIsMajorTimeStep = rtmIsMajorTimeStep(dofrobot_M);
    tmp = false;
    simulationData->mData->mIsSolverAssertCheck = tmp;
    simulationData->mData->mIsSolverCheckingCIC = false;
    simulationData->mData->mIsComputingJacobian = false;
    simulationData->mData->mIsEvaluatingF0 = false;
    simulationData->mData->mIsSolverRequestingReset = false;
    simulationData->mData->mIsModeUpdateTimeStep = rtsiIsModeUpdateTimeStep
      (&dofrobot_M->solverInfo);
    dofrobot_B.iv1[0] = 0;
    dofrobot_B.dv1[0] = dofrobot_B.INPUT_1_1_1[0];
    dofrobot_B.dv1[1] = dofrobot_B.INPUT_1_1_1[1];
    dofrobot_B.dv1[2] = dofrobot_B.INPUT_1_1_1[2];
    dofrobot_B.dv1[3] = dofrobot_B.INPUT_1_1_1[3];
    dofrobot_B.iv1[1] = 4;
    dofrobot_B.dv1[4] = dofrobot_B.INPUT_2_1_1[0];
    dofrobot_B.dv1[5] = dofrobot_B.INPUT_2_1_1[1];
    dofrobot_B.dv1[6] = dofrobot_B.INPUT_2_1_1[2];
    dofrobot_B.dv1[7] = dofrobot_B.INPUT_2_1_1[3];
    dofrobot_B.iv1[2] = 8;
    dofrobot_B.dv1[8] = dofrobot_B.INPUT_3_1_1[0];
    dofrobot_B.dv1[9] = dofrobot_B.INPUT_3_1_1[1];
    dofrobot_B.dv1[10] = dofrobot_B.INPUT_3_1_1[2];
    dofrobot_B.dv1[11] = dofrobot_B.INPUT_3_1_1[3];
    dofrobot_B.iv1[3] = 12;
    dofrobot_B.dv1[12] = dofrobot_B.INPUT_4_1_1[0];
    dofrobot_B.dv1[13] = dofrobot_B.INPUT_4_1_1[1];
    dofrobot_B.dv1[14] = dofrobot_B.INPUT_4_1_1[2];
    dofrobot_B.dv1[15] = dofrobot_B.INPUT_4_1_1[3];
    dofrobot_B.iv1[4] = 16;
    dofrobot_B.dv1[16] = dofrobot_B.INPUT_5_1_1[0];
    dofrobot_B.dv1[17] = dofrobot_B.INPUT_5_1_1[1];
    dofrobot_B.dv1[18] = dofrobot_B.INPUT_5_1_1[2];
    dofrobot_B.dv1[19] = dofrobot_B.INPUT_5_1_1[3];
    dofrobot_B.iv1[5] = 20;
    dofrobot_B.dv1[20] = dofrobot_B.INPUT_6_1_1[0];
    dofrobot_B.dv1[21] = dofrobot_B.INPUT_6_1_1[1];
    dofrobot_B.dv1[22] = dofrobot_B.INPUT_6_1_1[2];
    dofrobot_B.dv1[23] = dofrobot_B.INPUT_6_1_1[3];
    dofrobot_B.iv1[6] = 24;
    simulationData->mData->mInputValues.mN = 24;
    simulationData->mData->mInputValues.mX = &dofrobot_B.dv1[0];
    simulationData->mData->mInputOffsets.mN = 7;
    simulationData->mData->mInputOffsets.mX = &dofrobot_B.iv1[0];
    diagnosticManager = (NeuDiagnosticManager *)dofrobot_DW.STATE_1_DiagMgr;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_0 = ne_simulator_method((NeslSimulator *)dofrobot_DW.STATE_1_Simulator,
      NESL_SIM_UPDATE, simulationData, diagnosticManager);
    if (tmp_0 != 0) {
      tmp = error_buffer_is_empty(rtmGetErrorStatus(dofrobot_M));
      if (tmp) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(dofrobot_M, msg);
      }
    }

    /* End of Update for SimscapeExecutionBlock: '<S27>/STATE_1' */
  }

  /* External mode */
  rtExtModeUploadCheckTrigger(2);

  {                                    /* Sample time: [0.0s, 0.0s] */
    rtExtModeUpload(0, (real_T)dofrobot_M->Timing.t[0]);
  }

  {                                    /* Sample time: [0.01s, 0.0s] */
    rtExtModeUpload(1, (real_T)((dofrobot_M->Timing.clockTick1) * 0.01));
  }

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.0s, 0.0s] */
    if ((rtmGetTFinal(dofrobot_M)!=-1) &&
        !((rtmGetTFinal(dofrobot_M)-dofrobot_M->Timing.t[0]) >
          dofrobot_M->Timing.t[0] * (DBL_EPSILON))) {
      rtmSetErrorStatus(dofrobot_M, "Simulation finished");
    }

    if (rtmGetStopRequested(dofrobot_M)) {
      rtmSetErrorStatus(dofrobot_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  dofrobot_M->Timing.t[0] =
    ((time_T)(++dofrobot_M->Timing.clockTick0)) * dofrobot_M->Timing.stepSize0;

  {
    /* Update absolute timer for sample time: [0.01s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.01, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     */
    dofrobot_M->Timing.clockTick1++;
  }
}

/* Model initialize function */
void dofrobot_initialize(void)
{
  /* Registration code */
  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&dofrobot_M->solverInfo,
                          &dofrobot_M->Timing.simTimeStep);
    rtsiSetTPtr(&dofrobot_M->solverInfo, &rtmGetTPtr(dofrobot_M));
    rtsiSetStepSizePtr(&dofrobot_M->solverInfo, &dofrobot_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&dofrobot_M->solverInfo, (&rtmGetErrorStatus
      (dofrobot_M)));
    rtsiSetRTModelPtr(&dofrobot_M->solverInfo, dofrobot_M);
  }

  rtsiSetSimTimeStep(&dofrobot_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetIsMinorTimeStepWithModeChange(&dofrobot_M->solverInfo, false);
  rtsiSetIsContModeFrozen(&dofrobot_M->solverInfo, false);
  rtsiSetSolverName(&dofrobot_M->solverInfo,"FixedStepDiscrete");
  rtmSetTPtr(dofrobot_M, &dofrobot_M->Timing.tArray[0]);
  rtmSetTFinal(dofrobot_M, -1);
  dofrobot_M->Timing.stepSize0 = 0.01;

  /* External mode info */
  dofrobot_M->Sizes.checksums[0] = (1111197416U);
  dofrobot_M->Sizes.checksums[1] = (981353591U);
  dofrobot_M->Sizes.checksums[2] = (481222654U);
  dofrobot_M->Sizes.checksums[3] = (2523610361U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    dofrobot_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(dofrobot_M->extModeInfo,
      &dofrobot_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(dofrobot_M->extModeInfo, dofrobot_M->Sizes.checksums);
    rteiSetTPtr(dofrobot_M->extModeInfo, rtmGetTPtr(dofrobot_M));
  }

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    dofrobot_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 19;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;
  }

  {
    NeslSimulationData *tmp_1;
    NeslSimulator *tmp;
    NeuDiagnosticManager *diagnosticManager;
    NeuDiagnosticTree *diagnosticTree;
    char *msg;
    real_T tmp_2;
    int32_T tmp_3;
    boolean_T tmp_0;

    /* Start for SimscapeExecutionBlock: '<S27>/STATE_1' */
    tmp = nesl_lease_simulator("dofrobot/Solver Configuration_1", 0, 0);
    dofrobot_DW.STATE_1_Simulator = (void *)tmp;
    tmp_0 = pointer_is_null(dofrobot_DW.STATE_1_Simulator);
    if (tmp_0) {
      dofrobot_4a109994_1_gateway();
      tmp = nesl_lease_simulator("dofrobot/Solver Configuration_1", 0, 0);
      dofrobot_DW.STATE_1_Simulator = (void *)tmp;
    }

    tmp_1 = nesl_create_simulation_data();
    dofrobot_DW.STATE_1_SimData = (void *)tmp_1;
    diagnosticManager = rtw_create_diagnostics();
    dofrobot_DW.STATE_1_DiagMgr = (void *)diagnosticManager;
    dofrobot_B.modelParameters.mSolverType = NE_SOLVER_TYPE_ODE;
    dofrobot_B.modelParameters.mSolverAbsTol = 0.001;
    dofrobot_B.modelParameters.mSolverRelTol = 0.001;
    dofrobot_B.modelParameters.mSolverModifyAbsTol = NE_MODIFY_ABS_TOL_NO;
    dofrobot_B.modelParameters.mStartTime = 0.0;
    dofrobot_B.modelParameters.mLoadInitialState = false;
    dofrobot_B.modelParameters.mUseSimState = false;
    dofrobot_B.modelParameters.mLinTrimCompile = false;
    dofrobot_B.modelParameters.mLoggingMode = SSC_LOGGING_OFF;
    dofrobot_B.modelParameters.mRTWModifiedTimeStamp = 6.64509664E+8;
    dofrobot_B.modelParameters.mUseModelRefSolver = false;
    dofrobot_B.modelParameters.mTargetFPGAHIL = false;
    tmp_2 = 0.001;
    dofrobot_B.modelParameters.mSolverTolerance = tmp_2;
    tmp_2 = 0.01;
    dofrobot_B.modelParameters.mFixedStepSize = tmp_2;
    tmp_0 = false;
    dofrobot_B.modelParameters.mVariableStepSolver = tmp_0;
    tmp_0 = false;
    dofrobot_B.modelParameters.mIsUsingODEN = tmp_0;
    dofrobot_B.modelParameters.mZcDisabled = true;
    diagnosticManager = (NeuDiagnosticManager *)dofrobot_DW.STATE_1_DiagMgr;
    diagnosticTree = neu_diagnostic_manager_get_initial_tree(diagnosticManager);
    tmp_3 = nesl_initialize_simulator((NeslSimulator *)
      dofrobot_DW.STATE_1_Simulator, &dofrobot_B.modelParameters,
      diagnosticManager);
    if (tmp_3 != 0) {
      tmp_0 = error_buffer_is_empty(rtmGetErrorStatus(dofrobot_M));
      if (tmp_0) {
        msg = rtw_diagnostics_msg(diagnosticTree);
        rtmSetErrorStatus(dofrobot_M, msg);
      }
    }

    /* End of Start for SimscapeExecutionBlock: '<S27>/STATE_1' */
  }
}

/* Model terminate function */
void dofrobot_terminate(void)
{
  /* Terminate for SimscapeExecutionBlock: '<S27>/STATE_1' */
  neu_destroy_diagnostic_manager((NeuDiagnosticManager *)
    dofrobot_DW.STATE_1_DiagMgr);
  nesl_destroy_simulation_data((NeslSimulationData *)dofrobot_DW.STATE_1_SimData);
  nesl_erase_simulator("dofrobot/Solver Configuration_1");
  nesl_destroy_registry();
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
