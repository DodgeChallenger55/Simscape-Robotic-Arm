function varargout = Dof6(varargin)
    % GUI initialization code
    gui_Singleton = 1;
    gui_State = struct('gui_Name', mfilename, ...
                       'gui_Singleton', gui_Singleton, ...
                       'gui_OpeningFcn', @Dof6_OpeningFcn, ...
                       'gui_OutputFcn', @Dof6_OutputFcn, ...
                       'gui_LayoutFcn', [] , ...
                       'gui_Callback', []);
    if nargin && ischar(varargin{1})
        gui_State.gui_Callback = str2func(varargin{1});
    end
    if nargout
        [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
    else
        gui_mainfcn(gui_State, varargin{:});
    end
end

function Dof6_OpeningFcn(hObject, eventdata, handles, varargin)
    % Initialize the GUI and store the handles structure
    handles.output = hObject;

    % Ensure all GUI components are added to the handles structure
    for i = 1:6
        handles.(['slider' num2str(i)]) = findobj('Tag', ['slider' num2str(i)]);
        handles.(['edit' num2str(i)]) = findobj('Tag', ['edit' num2str(i)]);
    end

    % Update handles structure
    guidata(hObject, handles);
end

function varargout = Dof6_OutputFcn(hObject, eventdata, handles)
    % Output function to return the handles structure
    varargout{1} = handles.output;
end

% Slider callback to update the values in the edit boxes and model parameters
function slider_Callback(hObject, eventdata, handles)
    % Loop through sliders and update corresponding edit boxes and model parameters
    for i = 1:6
        % Ensure the slider and edit box exist in the handles structure
        if isfield(handles, ['slider' num2str(i)]) && isfield(handles, ['edit' num2str(i)])
            t = get(handles.(['slider' num2str(i)]), 'value');
            set(handles.(['edit' num2str(i)]), 'string', num2str(t));
            
            % Update the smiData structure in the MATLAB workspace
            evalin('base', ['smiData.RevoluteJoint(' num2str(i) ').Rz.Pos = ' num2str(t) ';']);
        else
            error(['Slider or Edit box ' num2str(i) ' not found in handles structure.']);
        end
    end

    % Update the transformation matrix
    t1 = get(handles.slider1, 'value');
    t2 = get(handles.slider2, 'value');
    t3 = get(handles.slider3, 'value');
    t4 = get(handles.slider4, 'value');
    t5 = get(handles.slider5, 'value');
    t6 = get(handles.slider6, 'value');

    A1 = [cosd(t1) 0 sind(t1) 0; sind(t1) 0 -cosd(t1) 0; 0 1 0 0; 0 0 0 1];
    A2 = [cosd(t2) -sind(t2) 0 450*cosd(t2); sind(t2) cosd(t2) 0 450*sind(t2); 0 0 1 0; 0 0 0 1];
    A3 = [cosd(t3) 0 sind(t3) 42*cosd(t3); sind(t3) 0 -cosd(t3) 42*sind(t3); 0 1 0 0; 0 0 0 1];
    A4 = [cosd(t4) 0 -sind(t4) 0; sind(t4) 0 cosd(t4) 0; 0 -1 0 460; 0 0 0 1];
    A5 = [cosd(t5) 0 sind(t5) 0; sind(t5) 0 -cosd(t5) 0; 0 1 0 0; 0 0 0 1];
    A6 = [cosd(t6) -sind(t6) 0 0; sind(t6) cosd(t6) 0 0; 0 0 1 82; 0 0 0 1];
    
    T = A1 * A2 * A3 * A4 * A5 * A6;
    Px = T(1,4);
    Py = T(2,4);
    Pz = T(3,4);

    set(handles.edit7, 'string', num2str(Px));
    set(handles.edit8, 'string', num2str(Py));
    set(handles.edit9, 'string', num2str(Pz));

    % Ensure the simulation is running
    ModelName = 'dofrobot';
    try
        if ~bdIsLoaded(ModelName)
            % Load the Simulink model if it is not already loaded
            load_system(ModelName);
        end
        set_param(ModelName, 'SimulationCommand', 'update');
    catch ME
        errordlg(['Error updating simulation: ' ME.message], 'Simulation Error');
    end
end

% Button callback to start simulation
function pushbutton1_Callback(hObject, eventdata, handles)
    ModelName = 'dofrobot';
    try
        if ~bdIsLoaded(ModelName)
            % Load the Simulink model if it is not already loaded
            load_system(ModelName);
        end
        open_system(ModelName);
        
        % Set simulation parameters
        set_param(ModelName, 'BlockReduction', 'off');
        set_param(ModelName, 'StopTime', 'inf');
        set_param(ModelName, 'SimulationMode', 'normal');
        
        % Start simulation in external mode
        set_param(ModelName, 'SimulationCommand', 'start');
        set_param(ModelName, 'SimulationCommand', 'connect');
    catch ME
        errordlg(['Error starting simulation: ' ME.message], 'Simulation Error');
    end
end

% Button callback to reset sliders and edit boxes
function pushbutton2_Callback(hObject, eventdata, handles)
    % Reset slider values and corresponding edit boxes
    for i = 1:6
        set(handles.(['slider' num2str(i)]), 'value', 0);
        set(handles.(['edit' num2str(i)]), 'string', '0');
        
        % Reset the smiData structure in the MATLAB workspace
        evalin('base', ['smiData.RevoluteJoint(' num2str(i) ').Rz.Pos = 0;']);
    end
    
    % Reset transformation matrix values
    Px = 0;
    Py = 0;
    Pz = 0;
    set(handles.edit7, 'string', num2str(Px));
    set(handles.edit8, 'string', num2str(Py));
    set(handles.edit9, 'string', num2str(Pz));
end

% Button callback for pushbutton3
function pushbutton3_Callback(hObject, eventdata, handles)
    % Add functionality for pushbutton3 here
    disp('Pushbutton 3 clicked');
    
    % Example: Display a message in a dialog box
    msgbox('Pushbutton 3 was clicked!', 'Button 3');
end

% CreateFcn for all edit boxes
function edit_CreateFcn(hObject, eventdata, handles)
    set(hObject, 'BackgroundColor', [1 1 1]); % Set background color to white
end

% CreateFcn for all sliders
function slider_CreateFcn(hObject, eventdata, handles)
    if isequal(get(hObject, 'BackgroundColor'), get(0, 'defaultUicontrolBackgroundColor'))
        set(hObject, 'BackgroundColor', [0.9 0.9 0.9]); % Set background color to light gray
    end
end

% Callback for slider1
function slider1_Callback(hObject, eventdata, handles)
    % Call the shared slider_Callback function
    slider_Callback(hObject, eventdata, handles);
end

% Callback for slider2
function slider2_Callback(hObject, eventdata, handles)
    % Call the shared slider_Callback function
    slider_Callback(hObject, eventdata, handles);
end

% Callback for slider3
function slider3_Callback(hObject, eventdata, handles)
    % Call the shared slider_Callback function
    slider_Callback(hObject, eventdata, handles);
end

% Callback for slider4
function slider4_Callback(hObject, eventdata, handles)
    % Call the shared slider_Callback function
    slider_Callback(hObject, eventdata, handles);
end

% Callback for slider5
function slider5_Callback(hObject, eventdata, handles)
    % Call the shared slider_Callback function
    slider_Callback(hObject, eventdata, handles);
end

% Callback for slider6
function slider6_Callback(hObject, eventdata, handles)
    % Call the shared slider_Callback function
    slider_Callback(hObject, eventdata, handles);
end
